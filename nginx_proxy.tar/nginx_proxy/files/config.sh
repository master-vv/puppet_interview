#! /bin/bash

mv /etc/nginx/sites-available/default /etc/nginx/sites-available/backup_default_settings
cp /etc/nginx/nginx.conf /etc/nginx/confbakup
sed -i  "41a\log_format custom_log_data \'\$remote_addr forwarded for \$http_x_real_ip - \$remote_user [\$time_local]\'" /etc/nginx/nginx.conf
sed -i  "42a\'\"\$request\" \$status \" request_time=\$request_time \"\'\;" /etc/nginx/nginx.conf
echo "" > /etc/nginx/sites-available/default
echo "server {" >> /etc/nginx/sites-available/default
echo "   listen        80;" >> /etc/nginx/sites-available/default
echo "   server_name   domain.com;" >> /etc/nginx/sites-available/default
echo "   if (\$host = domain.com) {" >> /etc/nginx/sites-available/default
echo "   return 301 https://$host$request_uri;" >> /etc/nginx/sites-available/default
echo "    }" >> /etc/nginx/sites-available/default
echo " return 404;" >> /etc/nginx/sites-available/default
echo "}" >> /etc/nginx/sites-available/default
echo "" >> /etc/nginx/sites-available/default
echo "server {" >> /etc/nginx/sites-available/default
echo "   listen 443 ssl;" >> /etc/nginx/sites-available/default
echo "   ssl_certificate /etc/letsencrypt/live/domain.com/fullchain.pem;" >> /etc/nginx/sites-available/default
echo "   ssl_certificate_key /etc/letsencrypt/live/domain.com/privkey.pem;" >> /etc/nginx/sites-available/default
echo "   include /etc/letsencrypt/options-ssl-nginx.conf;" >> /etc/nginx/sites-available/default
echo "   ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;" >> /etc/nginx/sites-available/default
echo "" >> /etc/nginx/sites-available/default
echo "   server_name   domain.com;" >> /etc/nginx/sites-available/default
echo "   location / {" >> /etc/nginx/sites-available/default
echo "      proxy_pass         http://10.10.10.10;" >> /etc/nginx/sites-available/default
echo "      proxy_set_header   Host $host;;" >> /etc/nginx/sites-available/default
echo "      proxy_set_header   X-Real-IP $remote_addr;" >> /etc/nginx/sites-available/default
echo "    }" >> /etc/nginx/sites-available/default
echo "" >> /etc/nginx/sites-available/default
echo "   location /resoure2 {" >> /etc/nginx/sites-available/default
echo "      proxy_pass         http://20.20.20.20;" >> /etc/nginx/sites-available/default
echo "      proxy_set_header   Host $host;;" >> /etc/nginx/sites-available/default
echo "      proxy_set_header   X-Real-IP $remote_addr;" >> /etc/nginx/sites-available/default
echo "    }" >> /etc/nginx/sites-available/default
echo "}" >> /etc/nginx/sites-available/default
echo "" >> /etc/nginx/sites-available/default
echo "server {" >> /etc/nginx/sites-available/default
echo "   listen 8888;" >> /etc/nginx/sites-available/default
echo "   access_log /var/log/nginx/new.log custom_log_data;" >> /etc/nginx/sites-available/default
echo "   location / {" >> /etc/nginx/sites-available/default
echo "       resolver 1.1.1.1;" >> /etc/nginx/sites-available/default
echo "       proxy_pass http://$http_host$request_uri;" >> /etc/nginx/sites-available/default
echo "   }" >> /etc/nginx/sites-available/default
echo "}" >> /etc/nginx/sites-available/default
echo "" >> /etc/nginx/sites-available/default
nginx -t
systemctl restart nginx
